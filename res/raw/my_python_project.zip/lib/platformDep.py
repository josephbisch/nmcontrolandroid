import os
import platform

def getNamecoinDir():
    ret = ''
    if platform.system() == "Darwin":
        return os.path.expanduser("~/Library/Application Support/Namecoin/")
    elif platform.system() == "Windows":
        return os.path.join(os.environ['APPDATA'], "Namecoin")
    elif platform.system() == "linux" or platform.system() == 'linux2':
        ret = os.path.expanduser("~/.namecoin")
    if not os.path.exists(ret):
        # We must be on Android
        ret = os.path.join("/data", "data", "info.namecoin.nmcontrolandroid", "files")
    return ret

