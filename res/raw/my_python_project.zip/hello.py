import android, time
from nmcontrol import *

droid = android.Android()

droid.makeToast("Hello from NMControl for Android")
time.sleep(5)
main()
